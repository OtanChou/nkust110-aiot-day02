data = list("ABCDEFG")
for i, d in enumerate(data, 11):
    print(i, d)